The Windows version of TestDisk & PhotoRec should work under the following 64 bits edition of
- Windows XP 64
- Windows Server 2003
- Windows Server 2008
- Windows Server 2012
- Windows Server 2016
- Windows Server 2019
- Windows Vista
- Windows 7
- Windows 8
- Windows 10

32-bits version can be downloaded from
https://www.cgsecurity.org/wiki/TestDisk_Download

TestDisk doesn't need to be installed, you only need to
- extract the files
- run testdisk_win.exe or photorec_win.exe

TestDisk & PhotoRec documentation can be found online:
- https://www.cgsecurity.org/wiki/TestDisk
- https://www.cgsecurity.org/wiki/PhotoRec
