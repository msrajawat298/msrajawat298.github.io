module.exports = {
    apps : [{
      name   : "NGX",
      script : "npm",
      args: "start"
    }]
  }
  